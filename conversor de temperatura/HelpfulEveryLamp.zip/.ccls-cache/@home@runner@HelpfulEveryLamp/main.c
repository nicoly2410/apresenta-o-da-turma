#include <stdio.h>

// função da opção 1
void transformadorFC(double *resultado, double *t1) {
  (*resultado) = (*t1) * 1.8 + 32;
  printf("O resultado em fahreinheit é:%.2lf\n", *resultado);
}
// função da opção 2
void transformandoCF(double *resultado, double *t1) {
  (*resultado) = ((*t1) - 32) / 1.8;
  printf("O resultado em celsius é:%.2lf\n", *resultado);
}

int main() {
  int opcao;
  double t1;

  printf("Escolha o tipo da conversão\n");
  printf("1 - F->C\n");
  printf("2 - C->F\n");
  printf("3 - sair. \n");

  do {
    printf("Escreve a opção:");
    scanf("%d", &opcao);
    getchar();

    switch (opcao) {
    case 1:
      printf("Transformando F -> C.\n");
      printf("Escreve a temperatura:");
      scanf("%lf", &t1);
      double resultado = 0;
      transformadorFC(&resultado, &t1);
      break;

    case 2:
      printf("Transformando C -> F.\n");
      printf("Digite a temperartura:");
      scanf("%lf", &t1);
      double resultado2 = 0;
      transformandoCF(&resultado2, &t1);
      break;

    case 3:
      printf("Saindo ...\n");
      break;

    default:
      printf("Opção inválida.\n");
    }
  } while (opcao != 3);

  return 0;
}